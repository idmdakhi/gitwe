import type {
  GitRepository,
  CreateBranchOptions,
  MergeOptions,
  RawCommandResult,
} from "../../src/domain/ports/GitRepository";
import { Branch } from "../../src/domain/entities/Branch";
import { MergeOutcome } from "../../src/domain/valueObjects/MergeOutcome";
import { CommitInfo } from "../../src/domain/valueObjects/CommitInfo";
import { BranchAlreadyExistsError, BranchNotFoundError } from "../../src/domain/errors";

export class InMemoryGitRepository implements GitRepository {
  private branches = new Set<string>(["main"]);
  private current = "main";
  private workingTreeClean = true;
  private deletedBranches: string[] = [];
  private mergeLog: MergeOutcome[] = [];
  private tags: string[] = [];
  private pushedRemotes: string[] = [];
  private parents = new Map<string, string>();

  async getCurrentBranch(): Promise<string> {
    return this.current;
  }

  async listBranches(): Promise<Branch[]> {
    return [...this.branches].map((name) => new Branch(name, name === this.current, false));
  }

  async branchExists(name: string): Promise<boolean> {
    return this.branches.has(name);
  }

  async createBranch(name: string, options: CreateBranchOptions = {}): Promise<void> {
    if (this.branches.has(name)) throw new BranchAlreadyExistsError(name);
    this.branches.add(name);
    if (options.from) this.parents.set(name, options.from);
    if (options.checkout !== false) this.current = name;
  }

  async checkout(name: string): Promise<void> {
    if (!this.branches.has(name)) throw new BranchNotFoundError(name);
    this.current = name;
  }

  async merge(source: string, target: string, options: MergeOptions = {}): Promise<MergeOutcome> {
    if (!this.branches.has(source)) throw new BranchNotFoundError(source);
    if (!this.branches.has(target)) throw new BranchNotFoundError(target);
    this.current = target;
    const fastForward = options.strategy === "rebase" ? true : options.noFastForward === false;
    const outcome = MergeOutcome.of(source, target, fastForward);
    this.mergeLog.push(outcome);
    return outcome;
  }

  async deleteBranch(name: string): Promise<void> {
    if (!this.branches.has(name)) throw new BranchNotFoundError(name);
    this.branches.delete(name);
    this.deletedBranches.push(name);
  }

  async createTag(name: string): Promise<void> {
    this.tags.push(name);
  }

  async push(remote = "origin"): Promise<void> {
    this.pushedRemotes.push(remote);
  }

  async pull(): Promise<void> {}

  async getCommitInfo(): Promise<CommitInfo> {
    return { hash: "deadbeef", date: new Date(0), author: "test", message: "test commit" };
  }

  async getRecentCommits(): Promise<CommitInfo[]> {
    return [{ hash: "deadbeef", date: new Date(0), author: "test", message: "test commit" }];
  }

  async isMerged(branch: string, into: string): Promise<boolean> {
    // In-memory model has no real commit graph; approximate via the seeded parent chain.
    let current: string | undefined = branch;
    const visited = new Set<string>();
    while (current && !visited.has(current)) {
      if (current === into) return true;
      visited.add(current);
      current = this.parents.get(current);
    }
    return false;
  }

  async getBranchParent(branch: string): Promise<string | undefined> {
    return this.parents.get(branch);
  }

  async isWorkingTreeClean(): Promise<boolean> {
    return this.workingTreeClean;
  }

  async runRaw(): Promise<RawCommandResult> {
    return { stdout: "", stderr: "", exitCode: 0 };
  }

  // --- test helpers ---

  seedBranch(name: string, parent?: string): void {
    this.branches.add(name);
    if (parent) this.parents.set(name, parent);
  }

  setWorkingTreeClean(clean: boolean): void {
    this.workingTreeClean = clean;
  }

  getDeletedBranches(): readonly string[] {
    return this.deletedBranches;
  }

  getMergeLog(): readonly MergeOutcome[] {
    return this.mergeLog;
  }

  getTags(): readonly string[] {
    return this.tags;
  }

  getPushedRemotes(): readonly string[] {
    return this.pushedRemotes;
  }
}

