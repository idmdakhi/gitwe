package domain

import "context"

// MergeOptions mirrors git-repository.port.ts MergeOptions.
type MergeOptions struct {
	Message        string
	NoFastForward  bool
	Squash         bool
}

// TagOptions mirrors git-repository.port.ts TagOptions.
type TagOptions struct {
	Message    string
	Annotated  bool
	Sign       bool
	SigningKey string
}

// AheadBehind mirrors git-repository.port.ts AheadBehind.
type AheadBehind struct {
	Ahead  int
	Behind int
}

// GitRepository is everything the application layer needs from git.
// Implemented by a ShellGitRepository in infrastructure; use cases never
// shell out directly, which is what makes them unit-testable with a fake.
// Mirrors git-repository.port.ts. ctx is threaded through for cancellation
// and timeouts around the underlying `git` subprocess calls.
type GitRepository interface {
	Cwd() string

	CurrentBranch(ctx context.Context) (string, bool, error)
	ListBranches(ctx context.Context, pattern string) ([]string, error)
	BranchExists(ctx context.Context, branch string) (bool, error)
	RemoteBranchExists(ctx context.Context, remote, branch string) (bool, error)
	UpstreamOf(ctx context.Context, branch string) (string, bool, error)
	AheadBehind(ctx context.Context, ref, base string) (AheadBehind, error)
	IsAncestor(ctx context.Context, ancestor, descendant string) (bool, error)

	IsClean(ctx context.Context) (bool, error)
	ConflictedFiles(ctx context.Context) ([]string, error)
	MergeInProgress(ctx context.Context) (bool, error)

	CreateBranch(ctx context.Context, branch, startPoint string) error
	Checkout(ctx context.Context, branch string) error
	DeleteBranch(ctx context.Context, branch string, force bool) error
	DeleteRemoteBranch(ctx context.Context, remote, branch string) error
	RenameBranch(ctx context.Context, from, to string) error

	Merge(ctx context.Context, branch string, options *MergeOptions) error
	// ContinueMerge completes an in-progress merge after conflicts have been staged.
	ContinueMerge(ctx context.Context) error
	AbortMerge(ctx context.Context) error
	Rebase(ctx context.Context, onto string) error

	CreateTag(ctx context.Context, name string, options *TagOptions) error
	TagExists(ctx context.Context, name string) (bool, error)

	Fetch(ctx context.Context, remote, refspec string) error
	Push(ctx context.Context, remote, branch string, options *PushOptions) error
	RemoteExists(ctx context.Context, remote string) (bool, error)
	SetUpstream(ctx context.Context, branch, remote string) error
	ListTags(ctx context.Context) ([]string, error)
	DeleteTag(ctx context.Context, name string) error
	PushTags(ctx context.Context, remote, pattern string) error
	DeleteRemoteTag(ctx context.Context, remote, name string) error
	// Raw runs an arbitrary git command and returns stdout.
	Raw(ctx context.Context, args []string) (string, error)
	Graph(ctx context.Context, root string) (string, error)
}
