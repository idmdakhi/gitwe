package domain

import (
	"fmt"
	"regexp"
	"strings"
)

// invalidBranchChars mirrors the INVALID_CHARS regex in branch-name.vo.ts:
// whitespace, ~^:?*[\, "..", "@{", "//", leading "/", trailing "/",
// trailing ".lock", leading ".", trailing ".".
var invalidBranchChars = regexp.MustCompile(`[\s~^:?*\[\\]|\.\.|@\{|//+|^/|/$|\.lock$|^\.|\.$`)

// BranchName is a validated git branch short-name (the part after a type
// prefix, e.g. `login` in `feature/login`). Centralises the naming rules so
// every use case validates topic names the same way.
// Mirrors branch-name.vo.ts.
type BranchName struct {
	value string
}

// NewBranchName mirrors `BranchName.create(raw)`.
func NewBranchName(raw string) (BranchName, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return BranchName{}, NewValidationError("a branch name is required", "")
	}
	if invalidBranchChars.MatchString(trimmed) {
		return BranchName{}, NewValidationError(
			fmt.Sprintf("%q is not a valid git branch name", raw),
			`avoid spaces, `+"`"+`~^:?*[\`+"`"+`, consecutive slashes, and leading/trailing dots or slashes`,
		)
	}
	return BranchName{value: trimmed}, nil
}

func (b BranchName) String() string {
	return b.value
}
