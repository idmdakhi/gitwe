package domain

// BaseBranch is a long-lived branch of the workflow tree (e.g. `main`, `develop`).
// Mirrors base-branch.entity.ts.
type BaseBranch struct {
	Name      string   `yaml:"name" json:"name"`
	Aliases   []string `yaml:"aliases,omitempty" json:"aliases,omitempty"`
	Base      string   `yaml:"base,omitempty" json:"base,omitempty"` // parent base branch; empty for the root branch
	Protected bool     `yaml:"protected,omitempty" json:"protected,omitempty"`
}

// BranchType is a short-lived topic-branch category (e.g. `feature`, `hotfix`).
// Mirrors branch-type.entity.ts.
type BranchType struct {
	Name       string   `yaml:"name" json:"name"`
	Aliases    []string `yaml:"aliases,omitempty" json:"aliases,omitempty"`
	Base       string   `yaml:"base" json:"base"`
	Target     []string `yaml:"target" json:"target"`
	Prefix     string   `yaml:"prefix" json:"prefix"`
	PushRemote string   `yaml:"pushRemote,omitempty" json:"pushRemote,omitempty"`
}

// ResolvedBranch is a topic branch resolved against a concrete workflow definition.
type ResolvedBranch struct {
	Branch    string
	ShortName string
	Type      BranchType
}

// HookDefinition is an advanced hook entry with a condition/behaviour flags.
// Mirrors hook-config.entity.ts.
type HookDefinition struct {
	Script          string `yaml:"script" json:"script"`
	When            string `yaml:"when,omitempty" json:"when,omitempty"`
	ContinueOnError bool   `yaml:"continueOnError,omitempty" json:"continueOnError,omitempty"`
	Parallel        bool   `yaml:"parallel,omitempty" json:"parallel,omitempty"`
	Stdin           bool   `yaml:"stdin,omitempty" json:"stdin,omitempty"`
}

// HookConfig configures gitwe's hook system.
type HookConfig struct {
	Enabled       bool                                 `yaml:"enabled" json:"enabled"`
	Path          string                                `yaml:"path" json:"path"`
	Config        string                                `yaml:"config" json:"config"`
	Inline        map[string]string                     `yaml:"inline,omitempty" json:"inline,omitempty"`
	Advanced      map[string]HookDefinition              `yaml:"advanced,omitempty" json:"advanced,omitempty"`
	TypeOverrides map[string]map[string]HookDefinition   `yaml:"typeOverrides,omitempty" json:"typeOverrides,omitempty"`
}

// PushOptions mirrors git-repository.port.ts PushOptions.
type PushOptions struct {
	SetUpstream    bool `yaml:"setUpstream,omitempty" json:"setUpstream,omitempty"`
	Force          bool `yaml:"force,omitempty" json:"force,omitempty"`
	ForceWithLease bool `yaml:"forceWithLease,omitempty" json:"forceWithLease,omitempty"`
	FollowTags     bool `yaml:"followTags,omitempty" json:"followTags,omitempty"`
	Delete         bool `yaml:"delete,omitempty" json:"delete,omitempty"`
}

// RemoteOverride is per-branch/type override settings. Mirrors remote-config.entity.ts.
type RemoteOverride struct {
	Remote      string       `yaml:"remote,omitempty" json:"remote,omitempty"`
	Fetch       []string     `yaml:"fetch,omitempty" json:"fetch,omitempty"`
	Push        []string     `yaml:"push,omitempty" json:"push,omitempty"`
	AutoFetch   *bool        `yaml:"autoFetch,omitempty" json:"autoFetch,omitempty"`
	AutoPush    *bool        `yaml:"autoPush,omitempty" json:"autoPush,omitempty"`
	PushOptions *PushOptions `yaml:"pushOptions,omitempty" json:"pushOptions,omitempty"`
}

// RemoteConfig configures where gitwe fetches/pushes.
type RemoteConfig struct {
	Config        string                    `yaml:"config,omitempty" json:"config,omitempty"`
	Default       string                    `yaml:"default" json:"default"`
	Fetch         []string                  `yaml:"fetch" json:"fetch"`
	Push          []string                  `yaml:"push" json:"push"`
	AutoFetch     bool                      `yaml:"autoFetch" json:"autoFetch"`
	AutoPush      bool                      `yaml:"autoPush" json:"autoPush"`
	PushOptions   *PushOptions              `yaml:"pushOptions,omitempty" json:"pushOptions,omitempty"`
	BaseOverrides map[string]RemoteOverride `yaml:"baseOverrides,omitempty" json:"baseOverrides,omitempty"`
	TypeOverrides map[string]RemoteOverride `yaml:"typeOverrides,omitempty" json:"typeOverrides,omitempty"`
}

// VersionBump mirrors the `VersionBump` union type.
type VersionBump string

const (
	BumpMajor      VersionBump = "major"
	BumpMinor      VersionBump = "minor"
	BumpPatch      VersionBump = "patch"
	BumpPrerelease VersionBump = "prerelease"
	BumpNone       VersionBump = "none"
)

// PrereleaseConfig mirrors versioning-config.entity.ts PrereleaseConfig.
type PrereleaseConfig struct {
	Enabled bool     `yaml:"enabled" json:"enabled"`
	Format  string   `yaml:"format" json:"format"`
	Types   []string `yaml:"types" json:"types"`
}

// BumpRules maps a bump level to the branch types that trigger it.
type BumpRules struct {
	Major      []string `yaml:"major,omitempty" json:"major,omitempty"`
	Minor      []string `yaml:"minor,omitempty" json:"minor,omitempty"`
	Patch      []string `yaml:"patch,omitempty" json:"patch,omitempty"`
	Prerelease []string `yaml:"prerelease,omitempty" json:"prerelease,omitempty"`
}

// VersioningConfig mirrors VersioningFullConfig.
type VersioningConfig struct {
	Enabled       bool              `yaml:"enabled" json:"enabled"`
	Config        string            `yaml:"config,omitempty" json:"config,omitempty"`
	TagPrefix     string            `yaml:"tagPrefix,omitempty" json:"tagPrefix,omitempty"`
	TagTypes      []string          `yaml:"tagTypes,omitempty" json:"tagTypes,omitempty"`
	TagTargets    []string          `yaml:"tagTargets,omitempty" json:"tagTargets,omitempty"`
	BumpRules     *BumpRules        `yaml:"bumpRules,omitempty" json:"bumpRules,omitempty"`
	Format        string            `yaml:"format,omitempty" json:"format,omitempty"`
	Annotated     bool              `yaml:"annotated,omitempty" json:"annotated,omitempty"`
	Sign          bool              `yaml:"sign,omitempty" json:"sign,omitempty"`
	SigningKey    string            `yaml:"signingKey,omitempty" json:"signingKey,omitempty"`
	PushTags      bool              `yaml:"pushTags,omitempty" json:"pushTags,omitempty"`
	AutoCommit    bool              `yaml:"autoCommit,omitempty" json:"autoCommit,omitempty"`
	CommitMessage string            `yaml:"commitMessage,omitempty" json:"commitMessage,omitempty"`
	Prerelease    *PrereleaseConfig `yaml:"prerelease,omitempty" json:"prerelease,omitempty"`
}

// MergeStrategy mirrors the `MergeStrategy` union type.
type MergeStrategy string

const (
	MergeStrategyMerge  MergeStrategy = "merge"
	MergeStrategySquash MergeStrategy = "squash"
	MergeStrategyRebase MergeStrategy = "rebase"
)

// CliConfig mirrors workflow-config.entity.ts CliConfig.
type CliConfig struct {
	Enabled     bool              `yaml:"enabled" json:"enabled"`
	Interactive bool              `yaml:"interactive,omitempty" json:"interactive,omitempty"`
	Color       bool              `yaml:"color,omitempty" json:"color,omitempty"`
	Aliases     map[string]string `yaml:"aliases,omitempty" json:"aliases,omitempty"`
}

// SquashConfig mirrors workflow-config.entity.ts SquashConfig.
type SquashConfig struct {
	Enabled     bool     `yaml:"enabled" json:"enabled"`
	Default     bool     `yaml:"default" json:"default"`
	BranchTypes []string `yaml:"branchTypes" json:"branchTypes"`
}

// MergeConfig mirrors workflow-config.entity.ts MergeConfig.
type MergeConfig struct {
	Strategy       MergeStrategy            `yaml:"strategy" json:"strategy"`
	BranchTypes    map[string]MergeStrategy `yaml:"branchTypes,omitempty" json:"branchTypes,omitempty"`
	DeleteOnFinish []string                 `yaml:"deleteOnFinish" json:"deleteOnFinish"`
	Squash         *SquashConfig            `yaml:"squash,omitempty" json:"squash,omitempty"`
}

// ChangelogConfig mirrors workflow-config.entity.ts ChangelogConfig.
type ChangelogConfig struct {
	Enabled bool   `yaml:"enabled" json:"enabled"`
	Config  string `yaml:"config,omitempty" json:"config,omitempty"`
}

// WorkflowConfig is the root of `.gitwe/gitwe.yaml`. Mirrors workflow-config.entity.ts.
type WorkflowConfig struct {
	Version      int              `yaml:"version" json:"version"`
	Name         string           `yaml:"name" json:"name"`
	BaseBranches []BaseBranch     `yaml:"baseBranches" json:"baseBranches"`
	BranchTypes  []BranchType     `yaml:"branchTypes" json:"branchTypes"`
	Cli          *CliConfig       `yaml:"cli,omitempty" json:"cli,omitempty"`
	Merge        *MergeConfig     `yaml:"merge,omitempty" json:"merge,omitempty"`
	Hooks        *HookConfig      `yaml:"hooks,omitempty" json:"hooks,omitempty"`
	Versioning   *VersioningConfig `yaml:"versioning,omitempty" json:"versioning,omitempty"`
	Changelog    *ChangelogConfig `yaml:"changelog,omitempty" json:"changelog,omitempty"`
	Remote       *RemoteConfig    `yaml:"remote,omitempty" json:"remote,omitempty"`
}
