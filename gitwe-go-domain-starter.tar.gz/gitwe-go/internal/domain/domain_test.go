package domain

import "testing"

func TestBranchNameAcceptsSimpleNames(t *testing.T) {
	for _, ok := range []string{"login", "fix-123", "feature-x"} {
		if _, err := NewBranchName(ok); err != nil {
			t.Errorf("expected %q to be accepted, got error: %v", ok, err)
		}
	}
}

func TestBranchNameRejectsEmpty(t *testing.T) {
	if _, err := NewBranchName("   "); err == nil {
		t.Error("expected empty/whitespace name to be rejected")
	}
}

func TestBranchNameRejectsInvalidChars(t *testing.T) {
	bad := []string{
		"has space", "a~b", "a^b", "a:b", "a?b", "a*b", "a[b", `a\b`,
		"a..b", "a@{b", "a//b", "/leading", "trailing/", ".leading",
		"trailing.", "name.lock",
	}
	for _, name := range bad {
		if _, err := NewBranchName(name); err == nil {
			t.Errorf("expected %q to be rejected", name)
		}
	}
}

func TestGitweErrorCodeAndHint(t *testing.T) {
	err := NewNotInitializedError("")
	if err.Code() != CodeNotInitialized {
		t.Errorf("expected code %s, got %s", CodeNotInitialized, err.Code())
	}
	hint, ok := err.Hint()
	if !ok || hint == "" {
		t.Error("expected NotInitializedError to carry a hint")
	}
}
