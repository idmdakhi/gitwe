// Package domain contains the pure, I/O-free core of gitwe: workflow
// entities, value objects, errors, and the ports (interfaces) that the
// application layer depends on. Mirrors src/domain/*.ts.
package domain

import "fmt"

// Code is a stable, machine-readable error code (for JSON output, tests, etc).
type Code string

const (
	CodeConfig              Code = "CONFIG"
	CodeValidation           Code = "VALIDATION"
	CodeConflict             Code = "CONFLICT"
	CodeNotInitialized       Code = "NOT_INITIALIZED"
	CodeOperationInProgress  Code = "OPERATION_IN_PROGRESS"
	CodeGit                  Code = "GIT"
)

// GitweError is the single error type used across the domain and
// application layers. Every error carries a stable machine-readable
// Code plus an optional human-facing Hint, so the CLI layer never has
// to guess how to explain a failure to the user.
// Mirrors the GitweError class hierarchy in errors/index.ts.
type GitweError struct {
	ErrCode Code
	Message string
	ErrHint string // empty means "no hint"
	Files   []string
}

func (e *GitweError) Error() string {
	return e.Message
}

func (e *GitweError) Code() Code {
	return e.ErrCode
}

// Hint returns the human-facing suggestion, and whether one is set.
func (e *GitweError) Hint() (string, bool) {
	if e.ErrHint == "" {
		return "", false
	}
	return e.ErrHint, true
}

// NewConfigError mirrors `new ConfigError(message, hint?)`.
func NewConfigError(message, hint string) *GitweError {
	if hint == "" {
		hint = "Check your workflow definition file (gitwe.yaml / gitwe.json)."
	}
	return &GitweError{ErrCode: CodeConfig, Message: message, ErrHint: hint}
}

// NewValidationError mirrors `new ValidationError(message, hint?)`.
func NewValidationError(message, hint string) *GitweError {
	return &GitweError{ErrCode: CodeValidation, Message: message, ErrHint: hint}
}

// NewConflictError mirrors `new ConflictError(message, files?, hint?)`.
func NewConflictError(message string, files []string, hint string) *GitweError {
	if hint == "" {
		hint = "Resolve the conflicts, stage the files, then run `gitwe finish --continue`. " +
			"To cancel, run `gitwe finish --abort`."
	}
	return &GitweError{ErrCode: CodeConflict, Message: message, ErrHint: hint, Files: files}
}

// NewNotInitializedError mirrors `new NotInitializedError(message?)`.
func NewNotInitializedError(message string) *GitweError {
	if message == "" {
		message = "Repository is not initialised with gitwe"
	}
	return &GitweError{
		ErrCode: CodeNotInitialized,
		Message: message,
		ErrHint: "Run `gitwe init` (or `gitwe init --preset classic`) to create a workflow definition.",
	}
}

// NewOperationInProgressError mirrors `new OperationInProgressError(operation)`.
func NewOperationInProgressError(operation string) *GitweError {
	return &GitweError{
		ErrCode: CodeOperationInProgress,
		Message: fmt.Sprintf("A %q operation is already in progress", operation),
		ErrHint: "Use `--continue` to resume it or `--abort` to cancel it.",
	}
}

// NewGitCommandError mirrors `new GitCommandError(message, hint?)`.
func NewGitCommandError(message, hint string) *GitweError {
	return &GitweError{ErrCode: CodeGit, Message: message, ErrHint: hint}
}
